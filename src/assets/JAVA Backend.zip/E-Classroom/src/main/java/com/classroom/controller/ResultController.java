package com.classroom.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.classroom.model.Result;
import com.classroom.service.ResultService;

@RestController
@RequestMapping("/result")
@CrossOrigin(origins = "http://localhost:4200")
public class ResultController {
	@Autowired
	private ResultService resultService;

	@PostMapping("/add")
	public ResponseEntity<Result> saveUser(@RequestBody Result result) {
		result.setDate(new Date());
//		System.out.println("Obtained map to work " + result.getAnswers());
		return new ResponseEntity<Result>(resultService.addResult(result), HttpStatus.CREATED);
	}

	@GetMapping("/get")
	public List<Result> getAllResults() {
		return resultService.getAllResults();
	}

	@GetMapping("/bystd/{std}")
	public List<Result> getResultsByStandard(@PathVariable String std) {
		return resultService.getResultsByStd(std);
	}

	@GetMapping("/bystudid/{id}")
	public ResponseEntity<List<Result>> getUserById(@PathVariable int id) {
		return new ResponseEntity<>(resultService.getResultByStudentId(id), HttpStatus.OK);
	}

	@GetMapping("/check/{id}/{subject}/{title}")
	public ResponseEntity<String> getCheckResult(@PathVariable int id, @PathVariable String subject,
			@PathVariable String title) {
		System.out.println(subject);
		if (resultService.checkResults(id, title, subject).size() >= 3) {
			return new ResponseEntity<>("Not Ok", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Ok", HttpStatus.OK);
		}
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteResult(@PathVariable int id) {
		return new ResponseEntity<>(resultService.deleteResult(id), HttpStatus.OK);
	}

	@PostMapping("/submit-answers")
	public ResponseEntity<String> submitAnswers(@RequestBody List<Map<String, Object>> answers) {
		// Handle the list of answers received from the frontend
		// Each map in the list represents the structure of a question and its given
		// answer

		// Example: Just printing the received data
		System.out.println("Received answers: " + answers);

		// Add your logic to save the answers or perform further actions

		return ResponseEntity.ok("Answers submitted successfully");
	}
}
