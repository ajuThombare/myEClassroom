package com.classroom.serviceImpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.model.Question;
import com.classroom.model.Quiz;
import com.classroom.repositiory.QuestionRepository;
import com.classroom.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	private QuestionRepository questionRepository;

//	@Autowired
//	private QuizService quizServices;

	@Override
	public Question addQuestion(Question question) {
		return this.questionRepository.save(question);
	}

	@Override
	public Question updateQuestion(Question question) {
		return this.questionRepository.save(question);
	}

	@Override
	public Set<Question> getQuestions() {
		return new HashSet<>(this.questionRepository.findAll());
	}

	@Override
	public Question getQuestion(int questionId) {
		return this.questionRepository.findById(questionId).get();
	}

	@Override
	public Set<Question> getQuestionsOfQuiz(Quiz quiz) {
		return this.questionRepository.findByQuiz(quiz);
	}

	@Override
	public void deleteQuestion(int quesId) {
		Question question = new Question();
		question.setQuesId(quesId);
		this.questionRepository.delete(question);
	}

	@Override
	public Question get(int questionsId) {
		return this.questionRepository.getOne(questionsId);
	}

	@Override
	public boolean isQuestionAlreadyExistsInQuiz(String content, Quiz quiz) {
		List<Question> questions = questionRepository.findByContentAndQuiz(content, quiz);

		// questions with the same content in the specified quiz, it's a duplicate
		return !questions.isEmpty();
	}

	@Override
	public List<Question> getShuffledQuestions(Quiz quiz) {

//		Quiz quiz = this.quizServices.getQuiz(qid);

		Set<Question> questions = getQuestionsOfQuiz(quiz);

		List<Question> list = new ArrayList<Question>(questions);

		Collections.shuffle(list);
		return list;

	}
}
