package com.classroom.serviceImpl;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Notes;
import com.classroom.model.Standard;
import com.classroom.model.StudentNotes;
import com.classroom.model.Subject;
import com.classroom.repositiory.NotesRepo;
import com.classroom.service.NotesService;
import com.classroom.service.StandardService;
import com.classroom.service.StudentNotesService;
import com.classroom.service.SubjectService;

@Service
public class NotesServiceImpl implements NotesService {

	@Autowired
	private NotesRepo notesrepo;
	@Autowired
	private StudentNotesService studentNotesService;
	@Autowired
	private StandardService standardService;
	@Autowired
	private SubjectService subjectService;

	@Override
	public Notes addNotes(Notes note) {
		// save note in original (teacher) notes table
		Notes saved = notesrepo.save(note);

		StudentNotes newNote = new StudentNotes();
		newNote.setId(saved.getId());
		newNote.setDate(saved.getDate());
		newNote.setFileName(saved.getFileName());
		newNote.setNote(saved.getNote());
		newNote.setTitle(saved.getTitle());
		newNote.setStandards(saved.getStandards());
		newNote.setSubjects(saved.getSubjects());
		// save note in student table
		studentNotesService.addNotes(newNote);

		return saved;
	}

	@Override
	public List<Notes> getAllNotes() {
		// TODO Auto-generated method stub
		return notesrepo.findAll();
	}

	@Override
	public void deleteNotes(int id) {
		// TODO Auto-generated method stub
		notesrepo.deleteById(id);
	}

	@Override
	public void deleteStudentNotes(int id) {
		notesrepo.deleteById(id);
		studentNotesService.deleteNotes(id);
	}

	@Override
	public Notes update(Notes updatedNotes) {
		// TODO Auto-generated method stub
		getNoteById(updatedNotes.getId());
		return notesrepo.save(updatedNotes);
	}

	@Override
	public Optional<Notes> getNoteById(int id) {
		// TODO Auto-generated method stub
		return Optional.ofNullable(
				notesrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));
	}

	@Override
	public List<Notes> getNotesByTeacherId(String id) {
		// TODO Auto-generated method stub
		List<Notes> findByTeacherId = notesrepo.findByTeacherId(id);
		for (Notes a : findByTeacherId) {
			Standard standard = a.getStandards();
			if (standard != null) {
				a.setStandard(standard.getName());
			} else {
				a.setStandard("Not Found");
			}
			Subject subject = a.getSubjects();
			if (subject != null) {
				a.setSubject(subject.getSname());
			} else {
				a.setSubject("Not Found");
			}
		}
		return findByTeacherId;
	}

	@Override
	public List<Notes> getNoteByTitle(String title) {
		return notesrepo.findByTitle(title);
	}

	@Override
	public Object addNotesServiceFun(MultipartFile noteFile, String noteTitle, String standard, String subject) {
		// TODO Auto-generated method stub
		Notes note = new Notes();
		if (!getNoteByTitle(noteTitle.split("-")[0]).isEmpty()) {
			return "CONFLICT";
		}
		note.setTitle(noteTitle.split("-")[0]);
		note.setTeacherId(noteTitle.split("-")[1]);
		if (noteFile.getOriginalFilename().length() > 50)
			note.setFileName(noteFile.getOriginalFilename().substring(0, 49));
		else {
			note.setFileName(noteFile.getOriginalFilename());
		}
		Standard findStandardByName = standardService.findStandardByName(standard);
		note.setStandards(findStandardByName);
		Subject subjectByName = subjectService.getSubjectByName(subject);
		note.setSubjects(subjectByName);
		try {
			note.setNote(noteFile.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		note.setDate(new Date());
		return addNotes(note);
	}

}
