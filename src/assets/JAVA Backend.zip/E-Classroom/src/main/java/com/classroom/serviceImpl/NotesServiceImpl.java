package com.classroom.serviceImpl;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Notes;
import com.classroom.model.StudentNotes;
import com.classroom.repositiory.NotesRepo;
import com.classroom.service.NotesService;
import com.classroom.service.StudentNotesService;

@Service
public class NotesServiceImpl implements NotesService {

	@Autowired
	private NotesRepo notesrepo;
	@Autowired
	private StudentNotesService studentNotesService;

	@Override
	public Notes addNotes(Notes note) {
		// save note in original (teacher) notes table
		Notes saved = notesrepo.save(note);

		StudentNotes newNote = new StudentNotes();
		newNote.setId(saved.getId());
		newNote.setDate(saved.getDate());
		newNote.setFileName(saved.getFileName());
		newNote.setNote(saved.getNote());
		newNote.setTitle(saved.getTitle());
		// save note in student table
		studentNotesService.addNotes(newNote);

		return saved;
	}

	@Override
	public List<Notes> getAllNotes() {
		// TODO Auto-generated method stub
		return notesrepo.findAll();
	}

	@Override
	public void deleteNotes(int id) {
		// TODO Auto-generated method stub
		notesrepo.deleteById(id);
	}

	@Override
	public void deleteStudentNotes(int id) {
		notesrepo.deleteById(id);
		studentNotesService.deleteNotes(id);
	}

	@Override
	public Notes update(Notes updatedNotes) {
		// TODO Auto-generated method stub
		getNoteById(updatedNotes.getId());
		return notesrepo.save(updatedNotes);
	}

	@Override
	public Optional<Notes> getNoteById(int id) {
		// TODO Auto-generated method stub
		return Optional.ofNullable(
				notesrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));
	}

	@Override
	public List<Notes> getNotesByTeacherId(String id) {
		// TODO Auto-generated method stub
		return notesrepo.findByTeacherId(id);
	}

	@Override
	public List<Notes> getNoteByTitle(String title) {
		return notesrepo.findByTitle(title);
	}

	@Override
	public Object addNotesServiceFun(MultipartFile noteFile, String noteTitle) {
		// TODO Auto-generated method stub
		Notes note = new Notes();
		if (!getNoteByTitle(noteTitle.split("-")[0]).isEmpty()) {
			return "CONFLICT";
		}
		note.setTitle(noteTitle.split("-")[0]);
		note.setTeacherId(noteTitle.split("-")[1]);
		if (noteFile.getOriginalFilename().length() > 50)
			note.setFileName(noteFile.getOriginalFilename().substring(0, 49));
		else {
			note.setFileName(noteFile.getOriginalFilename());
		}

		try {
			note.setNote(noteFile.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		note.setDate(new Date());
		return addNotes(note);
	}

}
