package com.classroom.service;

import java.util.List;
import java.util.Set;

import com.classroom.model.Question;
import com.classroom.model.Quiz;

public interface QuizService {

	public Quiz addQuiz(Quiz quiz);

	public Quiz updateQuiz(Quiz quiz);

	public Set<Quiz> getQuizzes();

	public Quiz getQuiz(int quizId);

	public Quiz getQuizByName(String name);

	public void deleteQuiz(int quizId);

	public List<Quiz> getActiveQuizzes();

	public List<Quiz> getQuizByUser(String id);

	public Object addQuestionServiceFun(int quizId, Question question);

	public boolean checkQuizWithSubAndTitle(String subject, String title);

	List<Quiz> getQuizzesByStandard(String stdid);
}
