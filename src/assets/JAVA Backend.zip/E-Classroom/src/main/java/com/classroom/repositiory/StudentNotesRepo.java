package com.classroom.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.StudentNotes;

public interface StudentNotesRepo extends JpaRepository<StudentNotes, Integer> {

}
