package com.classroom.model.dao;

import java.util.Map;

public class mapData {
	private Map<Integer, String> studentsanswers;

	public Map<Integer, String> getStudentsanswers() {
		return studentsanswers;
	}

	public void setStudentsanswers(Map<Integer, String> studentsanswers) {
		this.studentsanswers = studentsanswers;
	}

}
