package com.classroom.service;

import java.util.List;

import com.classroom.model.Admin;

public interface AdminService {

	Admin createAdmin(Admin admin);

	Admin createFirstAdmin();

	Admin updateAdmin(int id, Admin updatedAdmin);

	boolean deleteAdmin(int id);

	List<Admin> getAllAdmins();

	Admin getAdminById(int id);

	Admin authenticateAdmin(String username, String password);

}
