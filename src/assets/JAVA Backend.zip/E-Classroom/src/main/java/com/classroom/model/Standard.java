package com.classroom.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Standards")
public class Standard {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "standerd_sequence")
	@SequenceGenerator(name = "standerd_sequence", sequenceName = "standerd_sequence", allocationSize = 1, initialValue = 100)
	private int id;

	@Column(length = 10)
	private String name;

	@ManyToMany(cascade = CascadeType.ALL)
	@JsonIgnore
	private Set<Subject> subjects;

	public Standard() {
	}

	public Standard(int id, String name, Set<Subject> subjects) {
		super();
		this.id = id;
		this.name = name;
		this.subjects = subjects;
	}

	public Standard(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(Set<Subject> subjects) {
		this.subjects = subjects;
	}

}