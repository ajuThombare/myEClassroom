package com.classroom.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Standard;
import com.classroom.model.Subject;
import com.classroom.repositiory.StandardRepo;
import com.classroom.service.StandardService;

@Service
public class StandardServiceImpl implements StandardService {
	@Autowired
	private StandardRepo standardRepo;

	@Override
	public Standard savesStandard(Standard standard) {
		// TODO Auto-generated method stub
		Standard findStandardByName = findStandardByName(standard.getName());
		if (findStandardByName != null) {
			return null;
		}
		return standardRepo.save(standard);
	}

	@Override
	public boolean deleteStandard(int id) {
		// TODO Auto-generated method stub
		standardRepo.delete(getStandardById(id));
		return true;
	}

	@Override
	public Standard getStandardById(int id) {
		// TODO Auto-generated method stub
		return standardRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Standerd", "Id", id));
	}

	@Override
	public Standard findStandardByName(String standardName) {
		// TODO Auto-generated method stub
		return standardRepo.findByName(standardName);
	}

	@Override
	public List<Standard> getAllStandards() {
		// TODO Auto-generated method stub
		return standardRepo.findAll();
	}

	@Override
	public Subject updateStandard(int id, Subject subject) {
		// TODO Auto-generated method stub
		Standard standardById = getStandardById(id);
//		if(!present) {
		boolean anyMatch = getSubjectsByStandard(id).stream().map(a -> a.getSname())
				.anyMatch(a -> a.equals(subject.getSname()));
		if (!anyMatch) {
			standardById.getSubjects().add(subject);
			Standard saveStandard = saveStandard(standardById);
			if (saveStandard != null) {
				return subject;
			} else {
				return null;
			}
		} else {
			return null;
		}

	}

	@Override
	public List<Subject> getSubjectsByStandard(int id) {
		// TODO Auto-generated method stub
		return getStandardById(id).getSubjects().stream().toList();
	}

	@Override
	public Standard saveStandard(Standard standard) {
		// TODO Auto-generated method stub
		return standardRepo.save(standard);
	}

}