package com.classroom.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Subject")
public class Subject {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "subject_sequence")
	@SequenceGenerator(name = "subject_sequence", sequenceName = "subject_sequence", allocationSize = 1, initialValue = 100)
	private int sid;

	@Column(name = "subject_name")
	private String sname;

//	@ManyToOne(fetch = FetchType.LAZY)
//	private Subject subjects;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Subject(int sid, String sname) {
		super();
		this.sid = sid;
		this.sname = sname;
	}

	public Subject() {

	}

}