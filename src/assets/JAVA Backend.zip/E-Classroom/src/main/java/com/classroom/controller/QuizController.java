package com.classroom.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.classroom.model.Quiz;
import com.classroom.service.QuizService;

@RestController
@CrossOrigin("*")
@RequestMapping("/quiz")
public class QuizController {
	@Autowired
	private QuizService quizService;

	// add quiz service
	@PostMapping("/add")
	public ResponseEntity<?> add(@RequestBody Quiz quiz) {
		try {
			if (this.quizService.checkQuizWithSubAndTitle(quiz.getSubject(), quiz.getTitle())) {
				return new ResponseEntity<>(
						"The quiz with " + quiz.getTitle() + " already present in Subject " + quiz.getSubject(),
						HttpStatus.CONFLICT);
			} else {
				quiz.setDate(new Date());
				return ResponseEntity.ok(this.quizService.addQuiz(quiz));
			}
		} catch (Exception e) {
			return ResponseEntity.badRequest().build();
		}

	}

	// update quiz
	@PutMapping("/")
	public ResponseEntity<Quiz> update(@RequestBody Quiz quiz) {
		return ResponseEntity.ok(this.quizService.updateQuiz(quiz));
	}

	// get quiz
	@GetMapping("/")
	public ResponseEntity<?> quizzes() {
		return ResponseEntity.ok(this.quizService.getQuizzes());
	}

	// get quiz
	@GetMapping("/getbystd/{stdid}")
	public ResponseEntity<List<Quiz>> getQuizzesByStandard(@PathVariable("stdid") String stdid) {
		List<Quiz> quizzes = this.quizService.getQuizzesByStandard(stdid);
		return ResponseEntity.ok(quizzes);
	}
//	 @GetMapping("/gestd/{stdid}")
//	 public ResponseEntity<Set<Quiz>> getQuizzesByStandard(@PathVariable("stdid") int stdid) {
//	     Set<Quiz> quizzes = this.quizService.getQuizzesByStandard(stdid);
//	     return ResponseEntity.ok(quizzes);
//	 }

	@GetMapping("/teacher/{qid}")
	public List<Quiz> getQuizbyUser(@PathVariable("qid") String qid) {
		return this.quizService.getQuizByUser(qid);
	}

	// get single quiz
	@GetMapping("/{qid}")
	public Quiz quiz(@PathVariable("qid") int qid) {
		return this.quizService.getQuiz(qid);
	}

	// delete the quiz
	@DeleteMapping("/{qid}")
	public void delete(@PathVariable("qid") int qid) {
		this.quizService.deleteQuiz(qid);
	}

	// get active quizzes
	@GetMapping("/active")
	public List<Quiz> getActiveQuizzes() {
		return this.quizService.getActiveQuizzes();
	}

}
