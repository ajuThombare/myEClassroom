package com.classroom.repositiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.Notes;

public interface NotesRepo extends JpaRepository<Notes, Integer> {

	List<Notes> findByTeacherId(String teacherId);

	List<Notes> findByTitle(String title);

}
