package com.classroom.service;

import java.util.List;

import com.classroom.model.Leave;

public interface LeaveService {

	public List<Leave> getAllLeaves();

	public Object submitLeave(Leave leave);

	public List<Leave> getPendingLeave();

	public List<Leave> getMyLeave(int id);

	public void deleteRequest(int id);

	public Leave approveLeave(int id);

	public Leave declineLeave(int id);
}
