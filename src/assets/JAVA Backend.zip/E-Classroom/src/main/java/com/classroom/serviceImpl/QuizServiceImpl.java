package com.classroom.serviceImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.model.Question;
import com.classroom.model.Quiz;
import com.classroom.repositiory.QuizRepository;
import com.classroom.service.QuestionService;
import com.classroom.service.QuizService;

@Service
@Transactional
public class QuizServiceImpl implements QuizService {
	@Autowired
	private QuizRepository quizRepository;
	@Autowired
	private QuestionService questionService;

	@Override
	public Quiz addQuiz(Quiz quiz) {
		return this.quizRepository.save(quiz);
	}

	@Override
	public Quiz updateQuiz(Quiz quiz) {
		return this.quizRepository.save(quiz);
	}

	@Override
	public boolean checkQuizWithSubAndTitle(String subject, String title) {
		List<Quiz> findBySubjectsAndTitle = quizRepository.findBySubjectsAndTitle(subject, title);
		if (findBySubjectsAndTitle.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	public Set<Quiz> getQuizzes() {
		Set<Quiz> filteredQuizes = new HashSet<>();
		List<Quiz> allQuizes = this.quizRepository.findAll();
		for (Quiz a : allQuizes) {
			if (Integer.parseInt(a.getNumberOfQuestions()) == questionService.getQuestionsOfQuiz(a).size())
				filteredQuizes.add(a);
		}
		return filteredQuizes;
	}

	@Override
	public Quiz getQuiz(int quizId) {
		return this.quizRepository.findById(quizId).get();
	}

	@Override
	public void deleteQuiz(int quizId) {
		this.quizRepository.deleteById(quizId);
	}

	@Override
	public List<Quiz> getActiveQuizzes() {
		return this.quizRepository.findByActive(true);
	}

	@Override
	public List<Quiz> getQuizByUser(String id) {
		// TODO Auto-generated method stub
		return this.quizRepository.findByTeacherId(id);
	}

	@Override
	public Object addQuestionServiceFun(int quizId, Question question) {

		// get quiz by id
		Quiz quiz = getQuiz(quizId);
		if (quiz == null) {
			return "NOTFOUND";
		}
		// check for duplicate question
		if (questionService.isQuestionAlreadyExistsInQuiz(question.getContent(), quiz)) {
			return "CONFLICT";
		}
		// check the question limit of quiz
		Set<Question> questions = questionService.getQuestionsOfQuiz(quiz);
		if (questions.size() >= Integer.parseInt(quiz.getNumberOfQuestions())) {
			return "BADREQUEST";
		}
		// assign question with quiz
		question.setQuiz(quiz);
		Question addedQuestion = questionService.addQuestion(question);
		// this adds question

		return addedQuestion;
	}

}
