package com.classroom.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Attendence;
import com.classroom.model.Standard;
import com.classroom.model.Subject;
import com.classroom.model.User;
import com.classroom.model.UserHistory;
import com.classroom.repositiory.UserHistoryRepo;
import com.classroom.repositiory.UserRepo;
import com.classroom.service.AttendenceService;
import com.classroom.service.StandardService;
import com.classroom.service.UserService;

@Service
@Primary
public class UserServiceImpl implements UserService, UserDetailsService {
	@Autowired
	private UserRepo userRepo;

	@Autowired
	private UserHistoryRepo userHistoryRepo;

	@Autowired
	private AttendenceService attendenceService;

	@Autowired
	private StandardService standardService;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		User user = this.userRepo.findByUsername(username).get(0);
		if (user == null) {
			System.out.println("User not found");
			throw new UsernameNotFoundException("No user found !!");
		}

		return user;
	}

	@Override
	public Optional<User> getUserById(int id) {
		return Optional
				.ofNullable(userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));
	}

	@Override
	public Optional<User> getUserByUserId(int id) {
		return userRepo.findById(id);
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		List<User> findAll = userRepo.findAll();
		return findAll.stream().filter(a -> !a.getRole().equals("Admin")).collect(Collectors.toList());
	}

	@Override
	public List<User> getActiveUsers() {
		List<User> findAll = userRepo.findAll();
		return findAll.stream().filter(a -> !a.getRole().equals("Admin") && a.isEnabled()).collect(Collectors.toList());
	}

	@Override
	public User registerUser(User user) {
		// save data in original table
		User saved = userRepo.save(user);

		UserHistory historyUser = new UserHistory();
		historyUser.setUserid(saved.getId());
		historyUser.setFirstName(saved.getFirstName());
		historyUser.setLastName(saved.getLastName());
		historyUser.seteMail(saved.geteMail());
		historyUser.setRole(saved.getRole());
		historyUser.setMobileNo(saved.getMobileNo());
		historyUser.setUsername(saved.getUsername());
		historyUser.setCity(saved.getCity());
		historyUser.setState(saved.getState());
		historyUser.setCountry(saved.getCountry());
		// save data in history table
		userHistoryRepo.save(historyUser);

		return saved;
	}

	@Override
	public User updateUser(User updatedUser) {

		User user = getUserById(updatedUser.getId()).get();
		if (!user.getPassword().equals(updatedUser.getPassword()))
			user.setPassword(bCryptPasswordEncoder.encode(updatedUser.getPassword()));

		user.setFirstName(updatedUser.getFirstName());
		user.setLastName(updatedUser.getLastName());
		user.seteMail(updatedUser.geteMail());
		user.setMobileNo(updatedUser.getMobileNo());
		user.setUsername(updatedUser.getUsername());
		user.setCity(updatedUser.getCity());
		return userRepo.save(user);
	}

	@Override
	public List<User> deleteUser(int id) {
		User user = getUserById(id).get();
		userRepo.delete(user);
		return userRepo.findAll();

	}

	@Override
	public User loginUser(User user) {
//		System.out.println("inside login serviceimpl");
		User findByUsernameAndPassword = userRepo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		return findByUsernameAndPassword;
	}

	@Override
	public List<User> getAllStudents() {
		// TODO Auto-generated method stub
		return userRepo.findByRole("student");
	}

	@Override
	public List<User> getAllTeachers() {
		List<User> findByRole = userRepo.findByRole("teacher");
//		for(User a : findByRole) {
//			
//		}
		return findByRole.stream().filter(a -> a.isEnabled()).collect(Collectors.toList());
	}

	@Override
	public List<UserHistory> getAllHistoryUsers() {
		List<UserHistory> users = userHistoryRepo.findAll();
		for (UserHistory user : users) {
			Optional<User> userByUserId = getUserByUserId(user.getUserid());
			if (userByUserId.isPresent()) {
				if (userByUserId.get().isEnabled()) {
					user.setIsActive("Active");
				} else {
					user.setIsActive("Inactive");
				}
			} else {
				user.setIsActive("Declined");
			}
		}
		return users;
	}

	@Override
	public List<User> getUserByUsername(String username) {
		// TODO Auto-generated method stub
		return userRepo.findByUsername(username);
	}

	@Override
	public List<User> getUserByEmail(String mail) {
		// TODO Auto-generated method stub
		return userRepo.findByeMail(mail);
	}

	@Override
	public List<User> getUserByMobile(String mobile) {
		// TODO Auto-generated method stub
		return userRepo.findByMobileNo(mobile);
	}

	@Override
	public String addAttendance(int id, String status) {
		// TODO Auto-generated method stub
		Optional<User> userOptional = getUserById(id);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			// role is "student" before adding attendance
			if ("student".equalsIgnoreCase(user.getRole())) {
				boolean present = "present".equalsIgnoreCase(status);
				Attendence attend = new Attendence(id, present, new Date());
				attendenceService.saveAttendance(attend);
				return "OK";
			} else {
				return "UNAUTHORIZED";
			}
		}
		return "User is not Registered";
	}

	@Override
	public Object addUserServiceFun(User user) {
//		System.out.println(getUserByUsername(user.getUsername()));

		if (!getUserByEmail(user.geteMail()).isEmpty()) {
			return user.geteMail() + " mail is already in use.";
		} else if (!getUserByMobile(user.getMobileNo()).isEmpty()) {
			return user.getMobileNo() + " mobile number is already in use.";
		} else if (!getUserByUsername(user.getUsername()).isEmpty()) {
			return "User with username: " + user.getUsername() + " already present.";
		} else {

			List<Standard> standards = new ArrayList<>();
			List<Subject> subjects = new ArrayList<>();
			Standard standardById = null;
			if (!user.getStandardid().isEmpty()) {
				standardById = standardService.getStandardById(Integer.parseInt(user.getStandardid()));
				standards.add(standardById);
			}
			if (!user.getSubjectid().isEmpty() && standardById != null) {
				Subject subject = standardById.getSubjects().stream()
						.filter(a -> a.getSid() == Integer.parseInt(user.getSubjectid())).findFirst().orElse(null);

				subjects.add(subject);
			}
			user.setStandards(standards);
			user.setSubjects(subjects);
			user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));

			return registerUser(user);
		}
	}

	@Override
	public Object updateUserServiceFun(User user) {

		System.out.println(getUserByUsername(user.getUsername()));

		if (!getUserByEmail(user.geteMail()).isEmpty()
				&& getUserByEmail(user.geteMail()).get(0).getId() != user.getId()) {
			return user.geteMail() + " mail is already in use.";
		} else if (!getUserByMobile(user.getMobileNo()).isEmpty()
				&& getUserByMobile(user.getMobileNo()).get(0).getId() != user.getId()) {
			return user.getMobileNo() + " mobile number is already in use.";
		} else if (!getUserByUsername(user.getUsername()).isEmpty()
				&& getUserByUsername(user.getUsername()).get(0).getId() != user.getId()) {
			return "User with username: " + user.getUsername() + " already present.";
		} else {
			return updateUser(user);
		}
	}

	@Override
	public List<User> getPendingUsers() {
		return userRepo.findByEnabled(false);
	}

	@Override
	public Object activateUserAccountFun(int id) {
		// TODO Auto-generated method stub
		Optional<User> findById = userRepo.findById(id);
		if (findById.isPresent()) {
			User user = findById.get();
			user.setEnabled(true);
			return updateUser(user);
		} else {
			return "User with Id: " + id + " is not found.";
		}
	}

	@Override
	public List<User> getUserbyStandard(String std) {
		// TODO Auto-generated method stub
		Standard standard = standardService.findStandardByName(std);

		List<User> newStudents = new ArrayList<>();
		List<User> allStudents = getAllStudents();
		for (User a : allStudents) {
			if (a.getStandards().get(0).getId() == standard.getId()) {
				newStudents.add(a);
			}
		}
		return newStudents;
	}

	@Override
	public User createFirstAdmin() {
		// TODO Auto-generated method stub
		if (getUserByUsername("admin").isEmpty()) {
			User save = new User();
			save.setUsername("admin");
			save.setPassword(bCryptPasswordEncoder.encode("Admin@123"));
			save.setRole("Admin");
			save.setEnabled(true);
			save.setFirstName("Admin");
			save.setLastName("User");
			return userRepo.save(save);
		} else {
			return null;
		}
	}

}
