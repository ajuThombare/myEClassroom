package com.classroom.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Result;
import com.classroom.model.User;
import com.classroom.repositiory.ResultRepo;
import com.classroom.service.EmailService;
import com.classroom.service.ResultService;
import com.classroom.service.UserService;

@Service
public class ResultServiceImpl implements ResultService {

	@Autowired
	private ResultRepo resultrepo;

	@Autowired
	private UserService userService;

	@Autowired
	private EmailService emailService;

	@Override
	public List<Result> getAllResults() {
		// TODO Auto-generated method stub
		return resultrepo.findAll();
	}

	@Override
	@Async
	public Result addResult(Result result) {
		// TODO Auto-generated method stub
		String subject = "Quiz Result";
		StringBuilder body = new StringBuilder(
				"You have scored " + result.getMarks() + " in you're " + result.getTitle());
		if (result.getMarks() != 0) {
			body.insert(0,
					"Congratulations " + userService.getUserById(result.getStudentId()).get().getFirstName() + ", ");
		}
		Optional<User> user = userService.getUserById(result.getStudentId());
		if (user.isPresent()) {
			// Result Email is sent through other thread so application can return response
			// immediately to front end
			Thread thread = new Thread(() -> {
				emailService.sendEmail(user.get().geteMail(), subject, body.toString());
			});
			thread.setName("Email Thread");
			thread.setPriority(10);
			thread.start();
		}

		return resultrepo.save(result);
	}

	@Override
	public Optional<Result> getResultById(int id) {
		return Optional.ofNullable(
				resultrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));
	}

	@Override
	public List<Result> getResultByStudentId(int id) {
		if (!userService.getUserById(id).isEmpty()) {
			return resultrepo.findByStudentId(id);
		}
		return null;
	}

	@Override
	public String deleteResult(int id) {
		resultrepo.delete(getResultById(id).get());
		return "Deleted";
	}

	@Override
	public List<Result> checkResults(int studentId, String title, String subject) {
		return resultrepo.findByStudentIdAndTitleAndSubject(studentId, title, subject);
	}

	@Override
	public List<Result> getResultsByStd(String std) {
		// TODO Auto-generated method stub
		return resultrepo.findByStandard(std);
	}

}
