package com.classroom.serviceImpl;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Question;
import com.classroom.model.Quiz;
import com.classroom.model.Result;
import com.classroom.model.User;
import com.classroom.repositiory.ResultRepo;
import com.classroom.service.QuestionService;
import com.classroom.service.QuizService;
import com.classroom.service.ResultService;
import com.classroom.service.UserService;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.RGBColor;

@Service
public class ResultServiceImpl implements ResultService {

	@Autowired
	private ResultRepo resultrepo;

	@Autowired
	private UserService userService;

	@Autowired
	private QuizService quizService;

	@Autowired
	private QuestionService questionService;

	@Autowired
	private JavaMailSender javaMailSender;

	@Override
	public List<Result> getAllResults() {
		// TODO Auto-generated method stub
		return resultrepo.findAll();
	}

	@Override
	@Async
	public Result addResult(Result result) {

		String subject = "Quiz Result";
		StringBuilder body = new StringBuilder(
				"You have scored " + result.getMarks() + " in you're " + result.getTitle());
		if (result.getMarks() != 0) {
			body.insert(0,
					"Congratulations " + userService.getUserById(result.getStudentId()).get().getFirstName() + ", ");
		}
		Optional<User> user = userService.getUserById(result.getStudentId());
		if (user.isPresent()) {
			// Result Email is sent through other thread so application can return response
			// immediately to front end
			Thread thread = new Thread(() -> {
				sendEmailWithAttachment(user.get().geteMail(), subject, body.toString(), result);
			});
			thread.setName("Email Thread");
			thread.setPriority(10);
			thread.start();
		}

		return resultrepo.save(result);
	}

	@Override
	public Optional<Result> getResultById(int id) {
		return Optional.ofNullable(
				resultrepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));
	}

	@Override
	public List<Result> getResultByStudentId(int id) {
		if (!userService.getUserById(id).isEmpty()) {
			return resultrepo.findByStudentId(id);
		}
		return null;
	}

	@Override
	public String deleteResult(int id) {
		resultrepo.delete(getResultById(id).get());
		return "Deleted";
	}

	@Override
	public List<Result> checkResults(int studentId, String title, String subject) {
		return resultrepo.findByStudentIdAndTitleAndSubject(studentId, title, subject);
	}

	@Override
	public List<Result> getResultsByStd(String std) {
		// TODO Auto-generated method stub

		return resultrepo.findByStandard(std);
	}

	@Async
	private String getSubjectFromMap(List<Map<String, Object>> answers, int key) {
		String str = Integer.toString(key);
		for (Map<String, Object> maps : answers) {
			if (String.valueOf(maps.get("quesId")).equals((String) str)) {
				return (String) maps.get("givenAnswer");
			}
		}
		return "";
	}

	@Async
	public void sendEmailWithAttachment(String to, String subject, String body, Result result) {
		MimeMessage message = javaMailSender.createMimeMessage();

		MimeMessageHelper helper;

		try {
			helper = new MimeMessageHelper(message, true);
			helper.setFrom("ajaypt1942@gmail.com");
			helper.setTo(to);
			helper.setSubject(subject);
			helper.setText(body);

			helper.addAttachment(result.getTitle(), createPdfDataSource(result));
		} catch (MessagingException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		javaMailSender.send(message);
		System.out.println("sent succesfully");
	}

	public DataSource createPdfDataSource(Result result) throws IOException, DocumentException {

		User curStudent = userService.getUserById(result.getStudentId()).get();

		List<Map<String, Object>> answers = result.getAnswers();

		String content = "";
		String title = "Exam Result";
		ByteArrayOutputStream out = new ByteArrayOutputStream();

		Document document = new Document();
		PdfWriter.getInstance(document, out);
		document.open();

		Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 25, RGBColor.BLUE);

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String currentDate = dateFormat.format(new Date());
		document.add(new Paragraph("Exam Time : " + currentDate));
		Paragraph p = new Paragraph(title, font);
		p.setAlignment(Element.ALIGN_CENTER);
		document.add(p);

		Font font1 = FontFactory.getFont(FontFactory.HELVETICA, 20);
		Paragraph p1 = new Paragraph(content);
		p1.setAlignment(Element.ALIGN_CENTER);
		document.add(new Chunk("Congradulations! You Have Scored :" + result.getMarks() + " Marks."));
		document.add(p1);

		PdfPTable table = new PdfPTable(7);
		table.setWidthPercentage(100);
		table.setHorizontalAlignment(Element.ALIGN_CENTER);

		table.addCell(createCell("Question"));
		table.addCell(createCell("Option A"));
		table.addCell(createCell("Option B"));
		table.addCell(createCell("Option C"));
		table.addCell(createCell("Option D"));
		table.addCell(createCell("Correct Answer"));
		table.addCell(createCell("Student's Answer"));

		Quiz quizzes = quizService.getQuizByName(result.getTitle());

		document.add(new Paragraph("Test Name: " + quizzes.getTitle(), font1));
		document.add(new Paragraph("Name: " + curStudent.getFirstName() + " " + curStudent.getLastName()));
		document.add(new Paragraph("Subject: " + quizzes.getSubject()));
		document.add(new Paragraph("Total Marks: " + quizzes.getMaxMarks()));

		document.add(Chunk.NEWLINE);

		Set<Question> questions = questionService.getQuestionsOfQuiz(quizzes);
		String sub = "";
		for (Question question : questions) {

			sub = getSubjectFromMap(answers, question.getQuesId());

			table.addCell(question.getContent());
			table.addCell(createCell(question.getOption1()));
			table.addCell(createCell(question.getOption2()));
			table.addCell(createCell(question.getOption3()));
			table.addCell(createCell(question.getOption4()));
			table.addCell(createCell(question.getAnswer()));

			Color cellColor = sub.equalsIgnoreCase(question.getAnswer()) ? RGBColor.GREEN : RGBColor.RED;
			table.addCell(createColoredCell(sub, cellColor));
		}

		document.add(table);
		document.add(Chunk.NEWLINE);
		document.close();
		byte[] pdfBytes = out.toByteArray();
		return new ByteArrayDataSource(pdfBytes, "application/pdf");

	}

	private PdfPCell createColoredCell(String content, Color green) {
		PdfPCell cell = createCell(content);
		cell.setBackgroundColor(green);
		return cell;
	}

	private PdfPCell createCell(String content) {
		PdfPCell cell = new PdfPCell(new Paragraph(content));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		return cell;
	}
}