package com.classroom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.classroom.model.Admin;
import com.classroom.service.AdminService;

@Configuration
public class EclassroomConfigs {
	@Autowired
	private AdminService adminService;

	@Bean
	public JavaMailSender JavaMailSender() {
		return new JavaMailSenderImpl();
	}

	@Bean
	public Admin createAdminUser() {
		return adminService.createFirstAdmin();
	}
}
