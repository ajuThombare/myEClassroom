package com.classroom.repositiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.Leave;
import com.classroom.model.User;

public interface LeaveRepository extends JpaRepository<Leave, Integer> {
	List<Leave> getByTeacher(User teacher);
}
