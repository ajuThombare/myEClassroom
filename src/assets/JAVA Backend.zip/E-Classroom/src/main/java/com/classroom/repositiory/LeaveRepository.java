package com.classroom.repositiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.classroom.model.Leave;
import com.classroom.model.User;

public interface LeaveRepository extends JpaRepository<Leave, Integer> {
	List<Leave> getByTeacher(User teacher);

	@Query(value = "select * from Leave_details " + "where MONTH(start_date) = MONTH(CURRENT_DATE) "
			+ "and teacher_id  = :teacherid and status = :status and leavetype = :type", nativeQuery = true)
	List<Leave> getByTeacherAndStatusAndLeavetypeAndMonth(@Param("teacherid") int teacherid,
			@Param("status") boolean status, @Param("type") String type);

	@Query(value = "select * from Leave_details " + "where YEAR(start_date) = YEAR(CURRENT_DATE) "
			+ "and teacher_id  = :teacherid and status = :status and leavetype = :type", nativeQuery = true)
	List<Leave> getByTeacherAndStatusAndLeavetypeAndYear(@Param("teacherid") int teacherid,
			@Param("status") boolean status, @Param("type") String type);

//	List<Leave> getByTeacherAndMonth(User teacher);
}
