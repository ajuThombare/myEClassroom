package com.classroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.classroom.model.User;
import com.classroom.model.UserHistory;
import com.classroom.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {
	@Autowired
	private UserService userService;

	@PostMapping("/add")
	public ResponseEntity<?> saveUser(@Validated @RequestBody User user) {
//		System.out.println(user);
		Object obj = userService.addUserServiceFun(user);
		if (obj instanceof User) {
			return new ResponseEntity<User>((User) obj, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>((String) obj, HttpStatus.CONFLICT);
		}
	}

	@GetMapping("/get")
	public List<User> getAllUsers() {
//		System.out.println("get all  users");
		return userService.getAllUsers();
	}

	@GetMapping("/bystd/{std}")
	public List<User> getUserBystd(@PathVariable String std) {
		return (userService.getUserbyStandard(std));
	}

	@GetMapping("/get/pending")
	public List<User> getPendingUsers() {
		return userService.getPendingUsers();
	}

	@GetMapping("/history/get")
	public List<UserHistory> getAllHistoryUsers() {
		return userService.getAllHistoryUsers();
	}

	@GetMapping("/get/students")
	public List<User> getAllStudents() {
//		System.out.println("get all  students");
		return userService.getAllStudents();
	}

	@GetMapping("/get/teachers")
	public List<User> getAllTeachers() {
//		System.out.println("get all  students");
		return userService.getAllTeachers();
	}

	@GetMapping("/byid/{id}")
	public ResponseEntity<User> getUserById(@PathVariable int id) {
		return new ResponseEntity<>(userService.getUserById(id).get(), HttpStatus.OK);
	}

	@GetMapping("/onebyid/{id}")
	public User getOneUserById(@PathVariable int id) {
		return (userService.getUserById(id).get());
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateUser(@PathVariable int id, @Validated @RequestBody User updatedUser) {
		updatedUser.setId(id);
		Object obj = userService.updateUserServiceFun(updatedUser);
		if (obj instanceof User) {
			return new ResponseEntity<User>((User) obj, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>((String) obj, HttpStatus.CONFLICT);
		}
	}

	@PutMapping("/activate/{id}")
	public ResponseEntity<?> activateUser(@PathVariable int id) {

		Object obj = userService.activateUserAccountFun(id);
		if (obj instanceof User) {
			return new ResponseEntity<User>((User) obj, HttpStatus.ACCEPTED);
		} else {
			return new ResponseEntity<>((String) obj, HttpStatus.FORBIDDEN);
		}
	}

	@DeleteMapping("/delete/{id}")
	public List<User> deleteUser(@PathVariable int id) {
		return userService.deleteUser(id);
	}

	@PostMapping("/logincheck")
	public ResponseEntity<User> loginUser(@Validated @RequestBody User user) {
		User loginUser = userService.loginUser(user);
		if (loginUser != null && !loginUser.isEnabled()) {
			return new ResponseEntity<User>(userService.loginUser(user), HttpStatus.FORBIDDEN);
		} else {
			return new ResponseEntity<User>(userService.loginUser(user), HttpStatus.OK);
		}
	}
}

// Image storing in String formate

//	public static boolean deleteDir(String path)
//	{
//	    java.io.File dir = new java.io.File(path);
//	    if (dir.isDirectory())
//	    {
//	        String[] filesList = dir.list();
//	        for(String s : filesList)
//	        {
//	            boolean success = new java.io.File(dir, s).delete();
//	            if(!success)
//	            {
//	                return false;
//	            }
//	        }
//	    }
//	    return dir.delete();
//	}

//	@PostMapping("/uploadProfilePicture/{id}")
//	public ResponseEntity<String> uploadProfilePicturePath(@PathVariable int id,
//			@RequestParam("file") MultipartFile file) {
//	    try {
//	    	 System.out.println("this is line 106");
//
////	        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//	    	 boolean fileName=deleteDir(file.getOriginalFilename());
//	    	 if(fileName)
//	    	 { 
//	    		 System.out.println("inside if");
//
//	        String uniqueFileName = UUID.randomUUID() + "_" +file.getOriginalFilename();
////	        + fileName
// System.out.println("this is line 108");
//	        Path filePath = Paths.get(uploadDirectory, uniqueFileName);
//	        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
//
//	        User user = userService.uploadProfilePicturePath(id, filePath.toString());
//	    
//	        return ResponseEntity.ok("File uploaded successfully");
//	    	 }else {
//	    	  return ResponseEntity.ok("File Not uploaded successfully");
//
//	    	 }
//	    } catch (IOException e) {
//	        // Handle file upload errors and return an appropriate response
//	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File upload failed: " + e.getMessage());
//	    }
//	}

// Image storing in Byte[] formate
//@PostMapping("/uploadPicture/{id}")
//public User uploadProfilePicture(@PathVariable int id,
//        @RequestParam("file") MultipartFile file) throws IOException {
//	{
//	    try {
//	        byte[] profilePicture = file.getBytes();
//	        System.out.print("Received image bytes: " + profilePicture.length + " bytes");
//	        return userService.uploadProfilePicture(id, profilePicture);
//	    } catch (IOException e) {
//	        System.out.print("Error while reading file bytes: " + e.getMessage());
//	        e.printStackTrace();
//	    }
//	    return null;
//	}
//}
