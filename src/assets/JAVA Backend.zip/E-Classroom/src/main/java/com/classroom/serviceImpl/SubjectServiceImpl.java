package com.classroom.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.model.Standard;
import com.classroom.model.Subject;
import com.classroom.repositiory.SubjectRepo;
import com.classroom.service.StandardService;
import com.classroom.service.SubjectService;

@Service
public class SubjectServiceImpl implements SubjectService {

	@Autowired
	private SubjectRepo subjectRepo;
	@Autowired
	private StandardService standardService;

	@Override
	public Subject addSubjects(Subject subject) {
		// TODO Auto-generated method stub
		return subjectRepo.save(subject);
	}

	@Override
	public Subject addSubject(Subject subject, Standard standard) {
		// TODO Auto-generated method stub
//		subject.setStandard(standard);
		return subjectRepo.save(subject);
	}

	@Override
	public List<Subject> getAllSubjects() {
		// TODO Auto-generated method stub
		return subjectRepo.findAll();
	}

	@Override
	public Optional<Subject> getSubjectById(int id) {
		// TODO Auto-generated method stub
		return subjectRepo.findById(id);
	}

	@Override
	public Subject updateSubject(int id, Subject subject) {
		// TODO Auto-generated method stub
		return subjectRepo.save(subject);
	}

	@Override
	public void removeSubject(int id) {
		subjectRepo.delete(getSubjectById(id).get());
	}

	@Override
	public Subject getSubjectByName(String subjectName) {
		return subjectRepo.findBySname(subjectName);
	}

	@Override
	public List<Subject> getStandardwiseSubjects() {
		List<Subject> subjects = new ArrayList<>();
		List<Standard> allStandards = standardService.getAllStandards();
		int count = 0;
		for (Standard std : allStandards) {
			Set<Subject> sub = std.getSubjects();
			for (Subject subs : sub) {
				subjects.add(new Subject(++count, subs.getSname(), std.getName()));
			}
		}
		return subjects;
	}

}