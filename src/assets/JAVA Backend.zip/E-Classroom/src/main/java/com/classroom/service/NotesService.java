package com.classroom.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.classroom.model.Notes;

public interface NotesService {

	public Notes addNotes(Notes note);

	public Object addNotesServiceFun(MultipartFile noteFile, String noteTitle, String standard, String subject);

	public List<Notes> getAllNotes();

	public List<Notes> getNotesByTeacherId(String id);

	public void deleteNotes(int id);

	public void deleteStudentNotes(int id);

	public Notes update(Notes updatedNotes);

	public Optional<Notes> getNoteById(int id);

	public List<Notes> getNoteByTitle(String title);
}
