package com.classroom.configs;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.classroom.model.User;
import com.classroom.service.UserService;

@Configuration
public class EclassroomConfigs {
	@Autowired
	private UserService userService;

	@Bean
	public JavaMailSender javaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);

		mailSender.setUsername("ajaypt1942@gmail.com");
		mailSender.setPassword("htjo ianb sfdb hfwr"); // Use the App Password generated for your application

		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");

		return mailSender;
	}

	@Bean
	public User createAdminUser() {
		return userService.createFirstAdmin();
	}
}
