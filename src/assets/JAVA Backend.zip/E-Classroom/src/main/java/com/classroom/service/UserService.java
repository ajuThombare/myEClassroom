package com.classroom.service;

import java.util.List;
import java.util.Optional;

import com.classroom.model.User;
import com.classroom.model.UserHistory;

public interface UserService {
	public User registerUser(User user);

	public List<User> getAllUsers();

	public Optional<User> getUserById(int id);

	public Optional<User> getUserByUserId(int id);

	public User updateUser(User updatedUser);

	public List<User> deleteUser(int id);

	public User loginUser(User user);

	public List<User> getAllStudents();

	public List<User> getAllTeachers();

	public List<UserHistory> getAllHistoryUsers();

	public List<User> getUserByUsername(String username);

	public List<User> getUserByEmail(String mail);

	public List<User> getUserByMobile(String mobile);

	public String addAttendance(int id, String status);

	public Object addUserServiceFun(User user);

	public Object activateUserAccountFun(int id);

	public Object updateUserServiceFun(User user);

	public List<User> getPendingUsers();

	public List<User> getUserbyStandard(String std);

	public User createFirstAdmin();

}
