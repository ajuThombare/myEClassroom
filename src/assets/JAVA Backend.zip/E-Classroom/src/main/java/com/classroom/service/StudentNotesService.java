package com.classroom.service;

import java.util.List;
import java.util.Optional;

import com.classroom.model.StudentNotes;

public interface StudentNotesService {
	public StudentNotes addNotes(StudentNotes note);

	public List<StudentNotes> getAllNotes();

	public void deleteNotes(int id);

	public StudentNotes updateNote(StudentNotes updatedNotes);

	public Optional<StudentNotes> getUserById(int id);

}
