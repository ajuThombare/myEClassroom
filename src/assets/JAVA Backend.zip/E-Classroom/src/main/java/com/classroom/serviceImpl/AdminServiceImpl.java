package com.classroom.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.model.Admin;
import com.classroom.repositiory.AdminRepository;
import com.classroom.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	private AdminRepository adminRepository;

	@Override
	public Admin getAdminById(int id) {
		// TODO Auto-generated method stub
		return adminRepository.findById(id).orElse(null);
	}

	@Override
	public Admin createAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public Admin createFirstAdmin() {
		// TODO Auto-generated method stub
		if (adminRepository.findByUserNameAndPassword("admin", "Admin@123") == null) {
			return createAdmin(new Admin("admin", "Admin@123"));
		} else {
			return null;
		}
	}

	@Override
	public Admin updateAdmin(int id, Admin updatedAdmin) {
		// TODO Auto-generated method stub
		Admin existingAdmin = adminRepository.findById(id).orElse(null);
		if (existingAdmin == null) {
			return null; // Handle not found case
		}

		existingAdmin.setUserName(updatedAdmin.getUserName());
		existingAdmin.setPassword(updatedAdmin.getPassword());

		return adminRepository.save(existingAdmin);
	}

	@Override
	public boolean deleteAdmin(int id) {
		// TODO Auto-generated method stub
		if (adminRepository.existsById(id)) {
			adminRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Override
	public List<Admin> getAllAdmins() {

		return adminRepository.findAll();
	}

	@Override
	public Admin authenticateAdmin(String username, String password) {
		return adminRepository.findByUserNameAndPassword(username, password);
	}

}
