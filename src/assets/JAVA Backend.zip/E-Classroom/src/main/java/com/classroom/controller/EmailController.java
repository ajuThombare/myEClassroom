package com.classroom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.classroom.service.EmailService;
import com.classroom.service.UserService;

@RestController
@RequestMapping("/email")
public class EmailController {
	@Autowired
	private EmailService emailService;
	@Autowired
	UserService userService;

//	@EventListener(ApplicationReadyEvent.class)
	@PostMapping
	public String sendEmail() {
		String recipientEmail = "rajmulegaon@gmail.com";
		String subject = "This is Eclassroom Subject";
		String body = "The result is .............";
		emailService.sendEmail(recipientEmail, subject, body);
		return body;
	}
}
