package com.classroom.service;

import java.util.List;
import java.util.Optional;

import com.classroom.model.Standard;
import com.classroom.model.Subject;

public interface SubjectService {
	Subject addSubject(Subject subject, Standard standard);

	Subject addSubjects(Subject subject);

	List<Subject> getAllSubjects();

	List<Subject> getStandardwiseSubjects();

	Optional<Subject> getSubjectById(int id);

	Subject updateSubject(int id, Subject subject);

	void removeSubject(int id);

	Subject getSubjectByName(String subjectName);

}