package com.classroom.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.Standard;
import com.classroom.model.StudentNotes;
import com.classroom.repositiory.StudentNotesRepo;
import com.classroom.service.StandardService;
import com.classroom.service.StudentNotesService;

@Service
@Primary
public class StudentNotesServiceImpl implements StudentNotesService {

	@Autowired
	private StudentNotesRepo studentNotesRepo;
	@Autowired
	private StandardService standardService;
//	@Autowired
//	private SubjectService subjectService;

	@Override
	public StudentNotes addNotes(StudentNotes note) {
		// TODO Auto-generated method stub
		return studentNotesRepo.save(note);
	}

	@Override
	public List<StudentNotes> getAllNotes() {
		// TODO Auto-generated method stub
		return studentNotesRepo.findAll();
	}

	@Override
	public List<StudentNotes> getNotesByStandard(Standard standard) {
		// TODO Auto-generated method stub
		return studentNotesRepo.findByStandards(standard);
	}

	@Override
	public void deleteNotes(int id) {
		// TODO Auto-generated method stub
		studentNotesRepo.deleteById(id);
	}

	@Override
	public StudentNotes updateNote(StudentNotes updatedNotes) {
		// TODO Auto-generated method stub
		getUserById(updatedNotes.getId());
		return studentNotesRepo.save(updatedNotes);
	}

	@Override
	public Optional<StudentNotes> getUserById(int id) {
		// TODO Auto-generated method stub
		return Optional.ofNullable(
				studentNotesRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));

	}

	@Override
	public List<StudentNotes> getStandardNotes(String name) {
		// TODO Auto-generated method stub
		Standard findStandardByName = standardService.findStandardByName(name);

		List<StudentNotes> notesByStandard = getNotesByStandard(findStandardByName);
		for (StudentNotes a : notesByStandard) {
			a.setSubject(a.getSubjects().getSname());
		}
		return getNotesByStandard(findStandardByName);
	}

}
