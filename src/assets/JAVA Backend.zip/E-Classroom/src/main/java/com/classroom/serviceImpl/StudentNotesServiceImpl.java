package com.classroom.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.global.exceptions.ResourceNotFoundException;
import com.classroom.model.StudentNotes;
import com.classroom.repositiory.StudentNotesRepo;
import com.classroom.service.StudentNotesService;

@Service
public class StudentNotesServiceImpl implements StudentNotesService {

	@Autowired
	private StudentNotesRepo studentNotesRepo;

	@Override
	public StudentNotes addNotes(StudentNotes note) {
		// TODO Auto-generated method stub
		return studentNotesRepo.save(note);
	}

	@Override
	public List<StudentNotes> getAllNotes() {
		// TODO Auto-generated method stub
		return studentNotesRepo.findAll();
	}

	@Override
	public void deleteNotes(int id) {
		// TODO Auto-generated method stub
		studentNotesRepo.deleteById(id);
	}

	@Override
	public StudentNotes updateNote(StudentNotes updatedNotes) {
		// TODO Auto-generated method stub
		getUserById(updatedNotes.getId());
		return studentNotesRepo.save(updatedNotes);
	}

	@Override
	public Optional<StudentNotes> getUserById(int id) {
		// TODO Auto-generated method stub
		return Optional.ofNullable(
				studentNotesRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Person", "Id", id)));

	}

}
