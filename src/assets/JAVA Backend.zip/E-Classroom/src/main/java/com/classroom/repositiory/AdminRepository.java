package com.classroom.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {

	Admin findByUserName(String userName);

	Admin findByUserNameAndPassword(String userName, String password);
}
