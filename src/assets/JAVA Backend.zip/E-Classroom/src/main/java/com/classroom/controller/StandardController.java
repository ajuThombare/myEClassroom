package com.classroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.classroom.model.Standard;
import com.classroom.service.StandardService;

@RestController
@RequestMapping("/standard")
@CrossOrigin(origins = "http://localhost:4200")
public class StandardController {
	@Autowired
	private StandardService standardService;

	@GetMapping("/all")
	public ResponseEntity<List<Standard>> getStandard() {
		return new ResponseEntity<>(standardService.getAllStandards(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Standard> getStandardById(@PathVariable int id) {
		Standard standard = standardService.getStandardById(id);
		if (standard != null) {
			return new ResponseEntity<>(standard, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/add")
	public ResponseEntity<Standard> createStandard(@RequestBody Standard standard) {
		Standard createdStandard = standardService.savesStandard(standard);
		return new ResponseEntity<>(createdStandard, HttpStatus.CREATED);

	}

	@PutMapping("/{id}")
	public ResponseEntity<Standard> updateStandard(@PathVariable int id, @RequestBody Standard standard) {
//		Standard updatedStandard = standardService.updateStandard(id, standard);
//		if (updatedStandard != null) {
//			return new ResponseEntity<>(updatedStandard, HttpStatus.OK);
//		} else {
//			 new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
		return null;
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteStandard(@PathVariable int id) {
		boolean deleted = standardService.deleteStandard(id);
		if (deleted) {
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}