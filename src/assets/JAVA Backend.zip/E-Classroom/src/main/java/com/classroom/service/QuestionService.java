package com.classroom.service;

import java.util.List;
import java.util.Set;

import com.classroom.model.Question;
import com.classroom.model.Quiz;

public interface QuestionService {

	public Question addQuestion(Question question);

	public Question updateQuestion(Question question);

	public Set<Question> getQuestions();

	public Question getQuestion(int questionId);

	public Set<Question> getQuestionsOfQuiz(Quiz quiz);

	public void deleteQuestion(int quesId);

	public Question get(int questionsId);

	public boolean isQuestionAlreadyExistsInQuiz(String content, Quiz quiz);

	public List<Question> getShuffledQuestions(Quiz quiz);
}
