package com.classroom.service;

import com.classroom.model.Result;

public interface EmailService {
	public void sendEmail(String studentEmail, String subject, String body);

	public void sendEmailWithAttachment(String geteMail, String subject, String string, Result result);

}
