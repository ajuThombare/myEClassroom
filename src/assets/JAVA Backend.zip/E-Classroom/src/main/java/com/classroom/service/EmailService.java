package com.classroom.service;


public interface EmailService {
    public void sendEmail(String studentEmail, String subject, String body);

}
