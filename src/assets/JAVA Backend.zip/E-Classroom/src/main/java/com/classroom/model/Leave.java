package com.classroom.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "leave_details")
public class Leave {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "leave_sequence")
	@SequenceGenerator(name = "leave_sequence", sequenceName = "leave_sequence", allocationSize = 1, initialValue = 10)
	@Column(name = "leave_id")
	private int id;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "leavetype", length = 20)
	private String leavetype;

	@Column(name = "reason", length = 500)
	private String reason;

	private boolean status;
	private boolean declined;

//	private int leaves;

	@Transient
	private int teacherid;
	@Transient
	private String teachername;
	@Transient
	private String currentleavestatus;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	private User teacher;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

//	public int getLeaves() {
//		return leaves;
//	}
//
//	public void setLeaves(int leaves) {
//		this.leaves = leaves;
//	}

	public int getTeacherid() {
		return teacherid;
	}

	public String getCurrentleavestatus() {
		return currentleavestatus;
	}

	public void setCurrentleavestatus(String currentleavestatus) {
		this.currentleavestatus = currentleavestatus;
	}

	public void setTeacherid(int teacherid) {
		this.teacherid = teacherid;
	}

	public User getTeacher() {
		return teacher;
	}

	public void setTeacher(User teacher) {
		this.teacher = teacher;
	}

	public boolean isDeclined() {
		return declined;
	}

	public void setDeclined(boolean declined) {
		this.declined = declined;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}

}