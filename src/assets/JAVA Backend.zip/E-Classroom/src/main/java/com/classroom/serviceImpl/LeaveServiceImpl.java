package com.classroom.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.model.Leave;
import com.classroom.model.User;
import com.classroom.repositiory.LeaveRepository;
import com.classroom.service.LeaveService;
import com.classroom.service.UserService;

@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	private LeaveRepository leaveRepository;

	@Autowired
	private UserService userService;

	@Override
	public List<Leave> getAllLeaves() {
		// TODO Auto-generated method stub
		List<Leave> allLeaves = leaveRepository.findAll();
		List<Leave> ls = new ArrayList<>();

		for (Leave a : allLeaves) {
			a.setTeacherid(a.getTeacher().getId());
			a.setTeachername(a.getTeacher().getFirstName() + " " + a.getTeacher().getLastName());
			if (a.isStatus()) {
				a.setCurrentleavestatus("Approved");
			} else if (a.isDeclined()) {
				a.setCurrentleavestatus("Declined");
			} else if (!a.isStatus() && !a.isDeclined()) {
				a.setCurrentleavestatus("Waiting");
			}

			ls.add(a);
		}

		return ls;
	}

	@Override
	public Object submitLeave(Leave leave) {
		// TODO Auto-generated method stub
		Optional<User> user = userService.getUserById(leave.getTeacherid());
		if (user.isPresent()) {
//			System.out.println(leaveRepository.getByTeacher(user.get()).size());
			if (countLeaves(user.get()) >= 5) {
				return "The Max Leaves limit is reached.";
			}
			leave.setTeacher(user.get());
		}
		return leaveRepository.save(leave);
	}

	public long countLeaves(User user) {
		long count = 0;
		List<Leave> byTeacher = leaveRepository.getByTeacher(user);
		count = byTeacher.stream().filter(a -> a.isStatus()).count();
//		System.out.println(count);
		return count;
	}

	@Override
	public List<Leave> getPendingLeave() {
		// TODO Auto-generated method stub
		List<Leave> list = leaveRepository.findAll();
		List<Leave> ls = new ArrayList<>();
		for (Leave a : list) {
			if (!a.isStatus() && !a.isDeclined()) {
//			if (!a.isStatus()) {
				User teacher = a.getTeacher();
				if (teacher != null) {
					a.setTeacherid(teacher.getId());
					a.setTeachername(teacher.getFirstName() + " " + teacher.getLastName());
					ls.add(a);
				}
			}
		}
		return ls;
	}

	@Override
	public List<Leave> getMyLeave(int id) {
		List<Leave> ls = new ArrayList<>();

		Optional<User> user = userService.getUserById(id);
		if (user.isPresent()) {

			List<Leave> list = leaveRepository.getByTeacher(user.get());

			for (Leave a : list) {
				if (a.isStatus()) {
					a.setCurrentleavestatus("Approved");
				} else if (a.isDeclined()) {
					a.setCurrentleavestatus("Declined");
				} else if (!a.isStatus() && !a.isDeclined()) {
					a.setCurrentleavestatus("Waiting");
				}

				ls.add(a);
			}
		}
		return ls;
	}

	@Override
	public void deleteRequest(int id) {
		// TODO Auto-generated method stub
		Optional<Leave> findById2 = leaveRepository.findById(id);
		if (findById2.isPresent()) {
			leaveRepository.delete(findById2.get());
		}
	}

	@Override
	public Leave approveLeave(int id) {
		// TODO Auto-generated method stub
		Leave leave = null;
		Optional<Leave> findById2 = leaveRepository.findById(id);
		if (findById2.isPresent()) {
			leave = findById2.get();
			leave.setStatus(true);
			leave.setDeclined(false);
			leaveRepository.save(leave);
		}

		return leave;
	}

	@Override
	public Leave declineLeave(int id) {
		Leave leave = null;
		Optional<Leave> findById2 = leaveRepository.findById(id);
		if (findById2.isPresent()) {
			leave = findById2.get();
			leave.setStatus(false);
			leave.setDeclined(true);
			leaveRepository.save(leave);
		}

		return leave;
	}

}