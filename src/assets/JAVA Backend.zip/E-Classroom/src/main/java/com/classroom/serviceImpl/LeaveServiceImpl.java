package com.classroom.serviceImpl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.classroom.configs.LeaveCount;
import com.classroom.model.Leave;
import com.classroom.model.User;
import com.classroom.repositiory.LeaveRepository;
import com.classroom.service.LeaveService;
import com.classroom.service.UserService;

@Service
public class LeaveServiceImpl implements LeaveService {

	@Autowired
	private LeaveRepository leaveRepository;

	@Autowired
	private UserService userService;

	@Override
	public List<Leave> getAllLeaves() {
		// TODO Auto-generated method stub
		List<Leave> allLeaves = leaveRepository.findAll();
		List<Leave> ls = new ArrayList<>();

		for (Leave a : allLeaves) {
			a.setTeacherid(a.getTeacher().getId());
			a.setTeachername(a.getTeacher().getFirstName() + " " + a.getTeacher().getLastName());
			if (a.isStatus()) {
				a.setCurrentleavestatus("Approved");
			} else if (a.isDeclined()) {
				a.setCurrentleavestatus("Declined");
			} else if (!a.isStatus() && !a.isDeclined()) {
				a.setCurrentleavestatus("Waiting");
			}
			ls.add(a);
		}

		return ls;
	}

	@Override
	public Object submitLeave(Leave leave) {
		// TODO Auto-generated method stub
		Optional<User> user = userService.getUserById(leave.getTeacherid());
		if (user.isPresent()) {
//			System.out.println(leaveRepository.getByTeacher(user.get()).size());
			if (countLeaves(user.get()) >= getNumberOfLeaves()) {
				return "The Max Leaves limit is reached.";
			}
			leave.setTeacher(user.get());
		}
		return leaveRepository.save(leave);
	}

	public long countLeaves(User user) {
		long count = 0;
		List<Leave> byTeacher = leaveRepository.getByTeacher(user);
		count = byTeacher.stream().filter(a -> a.isStatus()).count();
//		System.out.println(count);
		return count;
	}

	@Override
	public List<Leave> getPendingLeave() {
		// TODO Auto-generated method stub
		List<Leave> list = leaveRepository.findAll();
		List<Leave> ls = new ArrayList<>();
		for (Leave a : list) {
			if (!a.isStatus() && !a.isDeclined()) {
//			if (!a.isStatus()) {
				User teacher = a.getTeacher();
				if (teacher != null) {
					a.setTeacherid(teacher.getId());
					a.setTeachername(teacher.getFirstName() + " " + teacher.getLastName());
					ls.add(a);
				}
			}
		}
		return ls;
	}

	@Override
	public List<Leave> getMyLeave(int id) {
		List<Leave> ls = new ArrayList<>();

		Optional<User> user = userService.getUserById(id);
		if (user.isPresent()) {

			List<Leave> list = leaveRepository.getByTeacher(user.get());

			for (Leave a : list) {
				if (a.isStatus()) {
					a.setCurrentleavestatus("Approved");
				} else if (a.isDeclined()) {
					a.setCurrentleavestatus("Declined");
				} else if (!a.isStatus() && !a.isDeclined()) {
					a.setCurrentleavestatus("Waiting");
				}

				ls.add(a);
			}
		}
		return ls;
	}

	public int getNumberOfLeaves() {
		int leaves = 0;
		for (Field a : LeaveCount.class.getFields()) {
			leaves = leaves + LeaveCount.valueOf(a.getName()).getCount();
		}
		return leaves;
	}

	@Override
	public Map<String, Integer> getAvailLeaves(int id) {
		String type;
		int size = 0;
		Map<String, Integer> map = new HashMap<>();

		Optional<User> user = userService.getUserById(id);
		if (user.isPresent()) {
			for (Field a : LeaveCount.class.getFields()) {
				type = a.getName();
				if (type.equalsIgnoreCase("METERNITY")) {
					size = leaveRepository.getByTeacherAndStatusAndLeavetypeAndYear(user.get().getId(), true, type)
							.size();
				} else {
					size = leaveRepository.getByTeacherAndStatusAndLeavetypeAndMonth(user.get().getId(), true, type)
							.size();
				}
				map.put(capitalizeFirstLetter(type), LeaveCount.valueOf(type).getCount() - size);
			}
//			List<Leave> list = leaveRepository.getByTeacher(user.get());
//			for (Leave a : list) {
//				if (a.isStatus()) {
//					current = a.getLeavetype();
//					Integer integer = map.get(current);
//					map.put(current, --integer);
//				}
//			}
		}
		return map;
	}

	private static String capitalizeFirstLetter(String input) {
		if (input == null || input.isEmpty()) {
			return input; // Handle null or empty strings
		}

		return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
	}

	@Override
	public void deleteRequest(int id) {
		// TODO Auto-generated method stub
		Optional<Leave> findById2 = leaveRepository.findById(id);
		if (findById2.isPresent()) {
			leaveRepository.delete(findById2.get());
		}
	}

	@Override
	public Leave approveLeave(int id) {
		// TODO Auto-generated method stub
		Leave leave = null;
		Optional<Leave> findById2 = leaveRepository.findById(id);
		if (findById2.isPresent()) {

			leave = findById2.get();
//			if (countLeaves(leave.getTeacher()) < getNumberOfLeaves()) {
			if (checkLeaveTypeLimit(leave)) {
				leave.setStatus(true);
				leave.setDeclined(false);
				leaveRepository.save(leave);
			} else {
				leave.setLeavetype("nonvalid");
			}
//			} else {
//				leave.setLeavetype("non");
//			}
		}

		return leave;
	}

	public boolean checkLeaveTypeLimit(Leave leave) {

		String type = leave.getLeavetype();
		User teacher = leave.getTeacher();
		int size = 0;
		if (type.equalsIgnoreCase("METERNITY")) {
			size = leaveRepository.getByTeacherAndStatusAndLeavetypeAndYear(teacher.getId(), true, type).size();
		} else {
			size = leaveRepository.getByTeacherAndStatusAndLeavetypeAndMonth(teacher.getId(), true, type).size();
		}
//		int size = leaveRepository.getByTeacherAndStatusAndLeavetype(teacher, true, type).size();
		if (size >= LeaveCount.valueOf(type.toUpperCase()).getCount()) {
			return false;
		}
		return true;
	}

	@Override
	public Leave declineLeave(int id) {
		Leave leave = null;
		Optional<Leave> findById2 = leaveRepository.findById(id);
		if (findById2.isPresent()) {
			leave = findById2.get();
			leave.setStatus(false);
			leave.setDeclined(true);
			leaveRepository.save(leave);
		}

		return leave;
	}

}