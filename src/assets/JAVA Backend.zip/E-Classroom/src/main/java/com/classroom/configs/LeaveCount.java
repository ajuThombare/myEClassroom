package com.classroom.configs;

public enum LeaveCount {
	CASUAL(2), MANDATORY(1), SICK(3), EARNED(1);

	private int count;

	private LeaveCount(final int count) {
		this.count = count;
	}

	public int getCount() {
		return count;
	}

}
