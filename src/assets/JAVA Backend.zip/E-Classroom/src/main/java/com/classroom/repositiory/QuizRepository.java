package com.classroom.repositiory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.Quiz;

public interface QuizRepository extends JpaRepository<Quiz, Integer> {

	public List<Quiz> findByActive(Boolean b);

	public List<Quiz> findByTeacherId(String teacherId);

	List<Quiz> findBySubjectAndTitle(String subjects, String title);

	List<Quiz> findByStandard(String standard);
}
